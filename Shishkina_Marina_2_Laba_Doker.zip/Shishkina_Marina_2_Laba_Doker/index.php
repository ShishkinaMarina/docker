<?php
$host = '95.131.149.21';
$db = 'mgpu_ico_etl_14';
$$user = 'mgpu_ico_etl14';
$pass = 'ZVjSoVl9';

try {
	$pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
	$pdo->setAttribute(PDO: : ATTR_ERRMODE, PDO: : ERRMODE_EXCEPTION);

	$stmt = $pdo->query("SELECT * FROM students LIMIT 10");
	while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
		echo $row['column_name'] . "<br>";
	}
} catch (Pdoexception $e)
	echo "Ошибка подключения: " . $e->getMessage();
}